<?php

session_start();
$_SESSION['from_game'] = true;
?>

<?php include 'partials-head.php'; ?>
<body>
    <?php include 'partials-nav.php'; ?>

    <main>
        <h1>Partie lancée !</h1>
        <form action="result.php" method="post">
            <p>Choisir une main à jouer :</p>

            <input type="radio" name="player_hand" value="rock" id="rock" required>
            <label for="rock">Pierre</label><br>

            <input type="radio" name="player_hand" value="paper" id="paper">
            <label for="paper">Papier</label><br>

            <input type="radio" name="player_hand" value="scissors" id="scissors">
            <label for="scissors">Ciseaux</label><br>

            <button type="submit">Jouer !</button>
        </form>
    </main>

    <?php include 'partials-footer.php'; ?>
</body>
</html>
