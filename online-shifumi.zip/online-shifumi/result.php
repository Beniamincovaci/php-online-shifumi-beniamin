<?php
session_start();


if (!isset($_SESSION['from_game']) || !isset($_POST['player_hand'])) {
    header('Location: game.php');
    exit;
}
unset($_SESSION['from_game']); 

$validHands = ['rock', 'paper', 'scissors'];
$playerHand = $_POST['player_hand'] ?? '';


if (!in_array($playerHand, $validHands)) {
    header('Location: game.php');
    exit;
}


$cpuHand = $validHands[array_rand($validHands)];


function getResult(string $player, string $cpu): string {
    if ($player === $cpu) return 'draw';
    if (
        ($player === 'rock' && $cpu === 'scissors') ||
        ($player === 'paper' && $cpu === 'rock') ||
        ($player === 'scissors' && $cpu === 'paper')
    ) {
        return 'win';
    }
    return 'lose';
}

$result = getResult($playerHand, $cpuHand);


$mysqli = new mysqli("localhost", "root", "", "shifumi");
if ($mysqli->connect_error) {
    die("Erreur de connexion : " . $mysqli->connect_error);
}


$stmt = $mysqli->prepare("INSERT INTO games (date, handPlayedByUser, handPlayedByCPU, result) VALUES (NOW(), ?, ?, ?)");
$stmt->bind_param("sss", $playerHand, $cpuHand, $result);

if (!$stmt->execute()) {
    die("Erreur lors de l'enregistrement : " . $stmt->error);
}

$stmt->close();
$mysqli->close();


function getMessage(string $result): string {
    return match ($result) {
        'win' => "Bravo ! Vous avez gagné 🎉",
        'lose' => "Dommage ! Vous avez perdu 😢",
        default => "Égalité ! 🤝",
    };
}

function translateHand(string $hand): string {
    return match ($hand) {
        'rock' => 'Pierre',
        'paper' => 'Papier',
        'scissors' => 'Ciseaux',
        default => 'Inconnu',
    };
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Résultat - Shifumi</title>
</head>
<body>
    <nav>
        <ul>
            <li><a href="./index.php">Accueil</a></li>
            <li><a href="./game.php">Nouvelle partie</a></li>
            <li><a href="./history.php">Historique des parties</a></li>
        </ul>
    </nav>
    <main>
        <h1>Résultat de la partie</h1>
        <p>Vous avez joué : <strong><?= htmlspecialchars(translateHand($playerHand)) ?></strong></p>
        <p>L'ordinateur a joué : <strong><?= htmlspecialchars(translateHand($cpuHand)) ?></strong></p>
        <p><strong><?= getMessage($result) ?></strong></p>
    </main>
    <footer>
         Online Shifumi</p>
    </footer>
</body>
</html>
