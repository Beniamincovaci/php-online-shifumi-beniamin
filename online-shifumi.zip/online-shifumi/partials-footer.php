<!-- partials/footer.php -->
    <footer>
        <p>Online shifumi</p>
    </footer>
</body>
</html>
