<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Shifumi - Historique des parties</title>
</head>
<body>
<nav>
    <ul>
        <li><a href="./index.php">Accueil</a></li>
        <li><a href="./game.php">Nouvelle partie</a></li>
        <li><a href="./history.php">Historique des parties</a></li>
    </ul>
</nav>
<main>
