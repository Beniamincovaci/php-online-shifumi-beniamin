<?php
require_once __DIR__ . '/includes-config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset'])) {
    $mysqli->query("DELETE FROM games");
}


$result = $mysqli->query("SELECT date, handPlayedByUser, handPlayedByCPU, result FROM games ORDER BY date DESC");
$games = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
$mysqli->close();


function traduireMain(string $main): string {
    return match($main) {
        'rock' => 'Pierre',
        'paper' => 'Papier',
        'scissors' => 'Ciseaux',
        default => 'Inconnu',
    };
}

function traduireRésultat(string $result): string {
    return match($result) {
        'win' => 'Victoire',
        'lose' => 'Défaite',
        'draw' => 'Égalité',
        default => 'Inconnu',
    };
}

require_once __DIR__ . '/includes-header.php';
?>

<h1>Historique des parties</h1>


<form method="post" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer tout l’historique ?');">
    <button type="submit" name="reset">Réinitialiser l'historique</button>
</form>


<?php if (empty($games)): ?>
    <p>Aucune partie enregistrée pour le moment.</p>
<?php else: ?>
    <table border="1" cellpadding="8">
        <thead>
            <tr>
                <th>Date</th>
                <th>Votre main</th>
                <th>Main de l'ordinateur</th>
                <th>Résultat</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($games as $game): ?>
                <tr>
                    <td><?= htmlspecialchars($game['date']) ?></td>
                    <td><?= traduireMain($game['handPlayedByUser']) ?></td>
                    <td><?= traduireMain($game['handPlayedByCPU']) ?></td>
                    <td><?= traduireRésultat($game['result']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php require_once __DIR__ . '/includes-footer.php'; ?>
